## Better than Wolves: Community Edition

Better than Wolves: Community Edition (BTW CE) is copyright (c) 2021-2024 BTW CE Team.

BTW CE is licensed under CC-BY 4.0, the summary and full text of which can be found here: https://creativecommons.org/licenses/by/4.0/

## Incorporated Code and Assets
### Code:
Distributed as part of BTW CE is the original Better than Wolves, licensed CC-BY 4.0, copyright (c) 2011-2020 FlowerChild

The code under `emi/` is licensed MIT, copyright (c) 2022 Emi

### Assets:
The following assets are licensed MIT, copyright (c) 2022 Emi
\
(EMI)
- All assets under `assets/emi/`

The following assets are licensed MIT, copyright (c) 2020 vectorwing
\
(Farmer's Delight)
- `assets/btw/textures/blocks/`:
  - dung.png
  - hamper.png
  - hamper_bottom.png
  - hamper_front.png
  - hamper_top.png
  - hamper_top_open.png
  - rope.png
  - rope_block.png
  - rope_block_top.png
  - wicker.png
  - wicker_basket.png
  - wicker_basket_bottom.png
  - wicker_basket_front.png
  - wicker_basket_top.png
  - wicker_basket_top_open.png
- `assets/btw/textures/items/`:
  - bread_dough.png
  - birch_bark.png
  - blood_wood_bark.png
  - chicken_soup.png
  - cooked_kebab.png
  - fried_egg.png
  - ham_and_eggs.png
  - jungle_bark.png
  - kibble.png
  - oak_bark.png
  - pork_dinner.png
  - rope.png
  - spruce_bark.png
  - steak_and_potatoes.png
  - steak_dinner.png
  - tasty_sandwich.png
  - unbaked_cake.png
  - unbaked_pumpkin_pie.png
  - wicker_pane.png
  - wolf_dinner.png

The following assets are licensed MIT, copyright (c) 2019 simibubi 
\
(Create)
- `assets/btw/textures/blocks/`:
  - piston_shovel.png
  - piston_shovel_edge_lower.png
  - piston_shovel_edge_middle.png
  - piston_shovel_edge_upper.png
- `assets/btw/textures/items/`:
  - clay_pile.png
  - dirt_pile.png
  - ender_spectacles.png
  - flour.png
  - gravel_pile.png
  - ground_netherrack.png
  - hellfire_dust.png
  - redstone_eye.png
  - sand_pile.png
  - soul_sand_pile.png
- `assets/btw/textures/models/armor/`:
  - special_layer_1.png
- `assets/btw/sound/`
  - misc/soul/possession_complete.ogg

The following assets are licensed MIT, copyright (c) 2024 MRH
\
(Create: Crafts and Additions)
- `assets/btw/textures/items/`:
  - element.png
  - filament.png

The following assets are licensed MIT, copyright (c) 2016-2018 BeetoGuy, primetoxinz, BordListian
\
(Better with Mods)
- `assets/btw/textures/items/`:
  - arcane_scroll.png
  - glue.png
  - mysterious_gland.png
  - witch_wart.png

The following assets are licensed MIT, copyright (c) 2022 Kitteh6660
\
(Variant Crafting Tables)
- `assets/btw/textures/blocks/`:
  - birch_work_stump.png
  - birch_work_stump_top.png
  - jungle_work_stump.png
  - jungle_work_stump_top.png
  - spruce_work_stump.png
  - spruce_work_stump_top.png

The following assets are licensed EUPL v1.2, copyright (c) 2023 Vexxel
\
(Vexxed Visuals)

The derivatives included in BTW CE based on Vexxel's work are distributed under MPL 1.1
- `assets/btw/textures/blocks/`:
  - charcoal_block.png
  - coal_ore_strata_3.png
  - cobblestone_strata_3.png
  - diamond_ore_strata_3.png
  - emerald_ore_strata_3.png
  - gold_ore_strata_3.png
  - iron_ore_strata_3.png
  - lapis_ore_strata_3.png
  - loose_cobblestone_strata_3.png
  - mossy_cobblestone_strata_3.png
  - nether_sludge.png
  - redstone_ore_strata_3.png
  - stone_strata_3.png
  - unfired_crude_brick.png
- `assets/btw/textures/items/`:
  - breeding_harness.png
  - chicken_feed.png
  - chocolate.png
  - chowder.png
  - cooked_cheval.png
  - cooked_mystery_meat.png
  - cooked_scrambled_eggs.png
  - cooked_wolfchop.png
  - cut_leather.png
  - cut_scoured_leather.png
  - cut_tanned_leather.png
  - fabric.png
  - gold_ore_pile.png
  - hearty_stew.png
  - iron_ore_pile.png
  - mashed_melon.png
  - nether_sludge.png
  - padded_boots.png
  - padded_chestplate.png
  - padded_helmet.png
  - padded_leggings.png
  - padding.png
  - potash.png
  - raw_cheval.png
  - raw_mystery_meat.png
  - raw_scrambled_eggs.png
  - raw_wolfchop.png
  - saw_dust.png
  - soul_dust.png
  - soul_flux.png
  - soul_urn.png
  - stone.png
  - stone_strata_2.png
  - stone_strata_3.png
  - stone_brick.png
  - stone_brick_strata_2.png
  - stone_brick_strata_3.png
  - straw.png
  - stump_remover.png
  - sugar_cane_roots.png
  - unfired_brick.png
  - unfired_crude_brick.png
  - unfired_nether_brick.png
  - urn.png
  - wheat_seeds.png
  - wool.png
  - wool_boots.png
  - wool_chestplate.png
  - wool_helmet.png
  - wool_leggings.png
  - wool_knit.png
- `assets/btw/textures/models/armor/`:
  - padded_layer_1.png
  - padded_layer_2.png
  - wool_layer_1.png
  - wool_layer_2.png
- `assets/minecraft/textures/items/`:
  - spider_eye_fermented.png

The following assets are licenced under a custom license (https://vanillatweaks.net/terms/), copyright (c) 2024 Vanilla Tweaks
\
(Vanilla Tweaks)
- `assets/btw/textures/blocks/`:
  - blood_wood_column.png
  - blood_wood_planks.png
- `assets/minecraft/textures/items`:
  - dye_powder_lime.png
  - dye_powder_magenta.png
  - dye_powder_pink.png
  - dye_powder_purple.png

### Copy of MIT license:

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.